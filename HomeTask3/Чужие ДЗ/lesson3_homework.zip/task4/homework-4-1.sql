USE shop;

SELECT id, name, birthday_at, created_at, updated_at
FROM shop.users
WHERE LOWER(DATE_FORMAT(birthday_at, "%M")) IN ('may', 'august')