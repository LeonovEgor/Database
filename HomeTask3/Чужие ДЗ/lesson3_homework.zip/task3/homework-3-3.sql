USE shop;

SELECT 
storehouse_id, 
product_id, 
value,
value / value AS in_stock

FROM storehouses_products
ORDER BY in_stock DESC, value ASC