USE shop;

UPDATE users 
SET updated_at = NOW(), created_at = NOW() 
WHERE updated_at IS NULL OR created_at IS NULL;