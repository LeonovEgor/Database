USE shop;

/* Чиним */

ALTER TABLE users RENAME COLUMN created_at TO created_at_str;
ALTER TABLE users RENAME COLUMN updated_at TO updated_at_str;

ALTER TABLE users ADD created_at DATETIME DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE users ADD updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

UPDATE users SET 
created_at = STR_TO_DATE(created_at_str, '%d.%m.%Y %H:%i'),
updated_at = STR_TO_DATE(updated_at_str, '%d.%m.%Y %H:%i');

ALTER TABLE users DROP created_at_str;
ALTER TABLE users DROP updated_at_str;

SELECT * FROM users;