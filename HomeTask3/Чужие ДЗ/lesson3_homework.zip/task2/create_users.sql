USE shop;

/* Ломаем */

DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id SERIAL PRIMARY KEY, 
  name VARCHAR(255) COMMENT 'Имя покупателя',
  birthday_at DATE COMMENT 'Дата рождения',
  created_at VARCHAR(255) COMMENT 'Время создания',
  updated_at VARCHAR(255) COMMENT 'Время обновления'
) COMMENT 'Покупатели';

INSERT INTO users (name, birthday_at, created_at, updated_at) VALUES
("Иван", "2012-11-14", "13.01.2019 1:56", "13.01.2019 1:56"),
("Петр", "2014-04-14", "01.01.2018 23:30", "01.01.2018 23:30"),
("Алексей", "2009-05-01", "11.05.2018 10:00", "11.05.2018 10:00"),
("Ольга", "2007-08-17", "17.08.2017 13:34", "17.08.2017 13:34"),
("Порфирий", "2014-04-14", "31.05.2019 23:59", "31.05.2019 23:59"),
("Митрофан", "2015-05-31", "20.10.2017 8:10", "20.10.2017 8:10");

SELECT * FROM users;