USE sample;

SELECT hello();
