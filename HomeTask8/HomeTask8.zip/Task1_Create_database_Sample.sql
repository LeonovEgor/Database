DROP database if exists sample;
CREATE  database sample;
USE sample;